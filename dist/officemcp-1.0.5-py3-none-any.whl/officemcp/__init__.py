# coding=utf-8
from officemcp import OfficeMCP
def main() -> None:
    OfficeMCP.RunOfficeMCP()